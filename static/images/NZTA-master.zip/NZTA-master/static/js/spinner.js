 let mask = document.querySelector('.mask');
    window.addEventListener('load', () => {
    mask.style.display = 'none'});